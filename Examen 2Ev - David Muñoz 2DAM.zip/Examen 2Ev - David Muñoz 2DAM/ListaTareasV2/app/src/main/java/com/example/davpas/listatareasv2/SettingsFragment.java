package com.example.davpas.listatareasv2;

import android.os.Bundle;
import android.preference.PreferenceFragment;

/**
 * Created by davpas on 2/2/18.
 */

public class SettingsFragment extends PreferenceFragment {
    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.opciones);
    }
}
